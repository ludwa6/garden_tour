
// sw.js - Simple redirect to main service worker
importScripts('./service-worker.js');
